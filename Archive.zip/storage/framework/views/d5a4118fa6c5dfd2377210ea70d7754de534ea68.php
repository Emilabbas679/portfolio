<?php $__env->startSection('title', 'Add Career'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary">Add Career </h6>
        </div>
        <div class="card-body">
            <div class="col-md-10 offset-md-1">
                <form class="user" method="POST" action="<?php echo e(route('career.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <ul class="nav nav-pills mb-3 ml-5" id="pills-tab" role="tablist">
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-tab-<?php echo e($locale->code); ?>"
                                   data-toggle="pill" href="#pills-<?php echo e($locale->code); ?>" role="tab"
                                   aria-controls="pills-<?php echo e($locale->code); ?>" aria-selected="true"><?php echo e($locale->language); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content pt-2 pl-1" id="pills-tabContent">
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-<?php echo e($locale->code); ?>"
                                 role="tabpanel" aria-labelledby="pills-tab-<?php echo e($locale->code); ?>">

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="position">Position <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">
                                        <input id="position" type="text" class="form-control <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                               name="position[<?php echo e($locale->code); ?>]" value="<?php echo e(old('position')); ?>"
                                               placeholder="<?php echo e(__('Position -').$locale->language); ?>" >
                                        <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="about">About <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">

                                        <textarea name="about[<?php echo e($locale->code); ?>]" id="" cols="30" rows="10" class="textarea <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> <?php echo e(old('about')); ?></textarea>
                                        <?php if ($errors->has('about')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="offers">Offers <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">

                                        <textarea name="offers[<?php echo e($locale->code); ?>]" id="" cols="30" rows="10" class="textarea <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> <?php echo e(old('offers')); ?></textarea>
                                        <?php if ($errors->has('offers')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('offers'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="requirements">Requirements <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">

                                        <textarea name="requirements[<?php echo e($locale->code); ?>]" id="" cols="30" rows="10" class="textarea <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> <?php echo e(old('requirements')); ?></textarea>
                                        <?php if ($errors->has('requirements')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('requirements'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                            </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group form-row">
                                    <div class="col-md-2"><label for="status">Status</label></div>
                                <div class="col-md-10">
                                    <select name="status" id="status" class="form-control">
                                        <option value="active"  selected>Active</option>
                                        <option value="inactive" >Inactive</option>
                                    </select>
                                </div>
                            </div>

                    </div>
                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo e(__('Save')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/admin/careers/create.blade.php ENDPATH**/ ?>