<?php $__env->startSection('title', 'News'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <a href="<?php echo e(route('news.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                All newss</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                        <th>#</th>
                        <td><?php echo e($news->id); ?></td>
                    </tr>
                    <tr>
                        <th>Title</th>
                        <td><?php echo e($news->title); ?></td>
                    </tr>


                    <tr>
                        <th>Slug</th>
                        <td><?php echo e($news->slug); ?></td>
                    </tr>

                    <tr>
                        <th>Content</th>
                        <td>
                            <?php echo $news->content; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>Image</th>
                        <td>
                            <img src="/public/uploads/news/<?php echo e($news->img); ?>" alt="" width="200">
                        </td>
                    </tr>


                    <tr>
                        <th>Status</th>
                        <td><?php echo e($news->status); ?></td>
                    </tr>

                    <tr>
                        <th>Created by</th>
                        <td><?php echo e($news->createdby->email); ?></td>
                    </tr>

                    <tr>
                        <th>Updated by</th>
                        <td><?php echo e($news->updatedby->email); ?></td>
                    </tr>


                    <tr>
                        <th>Created</th>
                        <td><?php echo e($news->created_at); ?></td>
                    </tr>
                    <tr>
                        <th>Updated</th>
                        <td><?php echo e($news->updated_at); ?></td>
                    </tr>
                    <tr>
                        <th>Operations</th>
                        <td>
                            <form id="delete-form" action="<?php echo e(route('news.destroy', $news->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a class="btn btn-primary btn-circle btn-sm" href="<?php echo e(route('news.edit', $news->id)); ?>">
                                    <i class="far fa-edit"></i>
                                </a>
                                <button class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/admin/news/show.blade.php ENDPATH**/ ?>