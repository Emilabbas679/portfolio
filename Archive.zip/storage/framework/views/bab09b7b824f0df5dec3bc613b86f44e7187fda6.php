<?php $__env->startSection('title', 'Edit News'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary">Edit <?php echo e($news->title); ?></h6>
        </div>
        <div class="card-body">
            <div class="col-md-10 offset-md-1">
                <form class="user" method="POST" action="<?php echo e(route('news.update', $news->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">

                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-tab-<?php echo e($locale->code); ?>"
                                   data-toggle="pill" href="#pills-<?php echo e($locale->code); ?>" role="tab"
                                   aria-controls="pills-<?php echo e($locale->code); ?>" aria-selected="true"><?php echo e($locale->language); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content pt-2 pl-1" id="pills-tabContent">
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-<?php echo e($locale->code); ?>"
                                 role="tabpanel" aria-labelledby="pills-tab-<?php echo e($locale->code); ?>">
                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="title-<?php echo e($locale->code); ?>">Title <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">
                                        <input id="title-<?php echo e($locale->code); ?>" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                               name="title[<?php echo e($locale->code); ?>]" value="<?php echo e($news->getTranslation('title', $locale->code)); ?>"
                                               placeholder="<?php echo e(__('Title -').$locale->code); ?>">
                                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>


                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="content-<?php echo e($locale->code); ?>">Content <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">
                                        <textarea name="content[<?php echo e($locale->code); ?>]" id="" cols="30" rows="10" class='textarea'>
                                            <?php echo e($news->getTranslation('content', $locale->code)); ?>

                                        </textarea>
                                        <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php if($news->img): ?>
                    <div class="form-group form-row">
                        <div class="col-md-2"><label for="old_img">Current Image</label></div>
                        <div class="col-md-10">
                            <img src="/public/uploads/news/<?php echo e($news->img); ?>" alt="" width="200">
                        </div>
                    </div>
                    <?php endif; ?>


                    <div class="form-group form-row">
                        <div class="col-md-2"><label for="img">New Image</label></div>
                        <div class="col-md-10">
                            <input type="file" name="img" class="form-control <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        </div>
                    </div>

                    <div class="form-group form-row">
                        <div class="col-md-2"><label for="status">Status</label></div>
                        <div class="col-md-10">
                            <select name="status" id="status" class="form-control">
                                <option value="active" <?php if($news->status == 'active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="inactive" <?php if($news->status == 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo e(__('Edit')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/admin/news/edit.blade.php ENDPATH**/ ?>