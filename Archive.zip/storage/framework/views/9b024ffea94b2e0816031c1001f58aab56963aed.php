<?php $__env->startSection('title', 'Update Language'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary">Update Language</h6>
        </div>
        <div class="card-body">
            <div class="col-md-6 offset-md-3">
                <form class="user" method="POST" action="<?php echo e(route('langs.update', $lang->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Language</label>
                        <div class="col-sm-9">
                            <input id="language" type="text" class="form-control <?php if ($errors->has('language')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('language'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                   name="language" value="<?php echo e($lang->language); ?>">
                            <?php if ($errors->has('language')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('language'); ?>
                            <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Code</label>
                        <div class="col-sm-9">
                            <input id="code" type="text" class="form-control <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                   name="code" value="<?php echo e($lang->code); ?>">
                            <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>



                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo e(__('Save')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/admin/langs/edit.blade.php ENDPATH**/ ?>