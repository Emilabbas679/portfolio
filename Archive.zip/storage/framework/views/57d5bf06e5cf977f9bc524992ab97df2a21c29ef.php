<?php $__env->startSection('title', 'Add News'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary">Add  </h6>
        </div>
        <div class="card-body">
            <div class="col-md-10 offset-md-1">
                <form class="user" method="POST" onsubmit="return validateForm()" name="createNews" action="<?php echo e(route('news.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <ul class="nav nav-pills mb-3 ml-5" id="pills-tab" role="tablist">
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-tab-<?php echo e($locale->code); ?>"
                                   data-toggle="pill" href="#pills-<?php echo e($locale->code); ?>" role="tab"
                                   aria-controls="pills-<?php echo e($locale->code); ?>" aria-selected="true"><?php echo e($locale->language); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content pt-2 pl-1" id="pills-tabContent">
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e(($locale->code == 'az') ? 'active': ''); ?>" id="pills-<?php echo e($locale->code); ?>"
                                 role="tabpanel" aria-labelledby="pills-tab-<?php echo e($locale->code); ?>">

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="title">Title <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">
                                        <input id="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                               name="title[<?php echo e($locale->code); ?>]" value="<?php echo e(old('title')); ?>"
                                               placeholder="<?php echo e(__('Title -').$locale->language); ?>" >
                                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group form-row">
                                    <div class="col-md-2"><label for="content">Content <?php echo e($locale->code); ?></label></div>
                                    <div class="col-md-10">

                                        <textarea name="content[<?php echo e($locale->code); ?>]" id="" cols="30" rows="10" class="textarea <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> <?php echo e(old('content')); ?></textarea>
                                        <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
                                        <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                            </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-group form-row">
                                <div class="col-md-2"><label for="img">Image </label></div>
                                <div class="col-md-10">
                                    <input id="img" type="file" class="form-control <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="img" value="<?php echo e(old('img')); ?>">
                                    <span class="invalid-feedback img-error-js"></span>

                                    <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>

                            <div class="form-group form-row">
                                <div class="col-md-2"><label for="status">Status</label></div>
                                <div class="col-md-10">
                                    <select name="status" id="status" class="form-control">
                                        <option value="active"  selected>Active</option>
                                        <option value="inactive" >Inactive</option>
                                    </select>
                                </div>
                            </div>


                    </div>
                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo e(__('Save')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>

    <script>
        function validateForm() {
            var img = document.forms["createNews"]["img"].value;
            if(img == ''){
                $('.img-error-js').html('Image is required');
                $('.img-error-js').show('');
                return false;

            }
            else{
                $('.img-error-js').hide('');
                return true;

            }

        }
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/admin/news/create.blade.php ENDPATH**/ ?>