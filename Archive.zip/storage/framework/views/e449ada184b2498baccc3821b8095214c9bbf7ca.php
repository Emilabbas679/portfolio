<?php $__env->startSection('title', $news->title); ?>
<?php $__env->startSection('content'); ?>
    <!-- subheader -->
    <section id="subheader" class="dark no-top no-bottom" data-bgimage="url(/public/images/background/bg-news.jpg) fixed" data-stellar-background-ratio=".2">
        <div class="overlay-bg t80">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo e($news->title); ?></h1>
                        <ul class="crumb">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="sep"></li>
                            <li><?php echo e($news->title); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- subheader close -->

    <!-- content begin -->
    <div id="content" class="no-top no-bottom">
        <section aria-label="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="blog-read">

                            <img src="/uploads/news/<?php echo e($news->img); ?>" class="img-responsive" alt="">

                            <div class="post-text">

                                <h3><a href="<?php echo e(route('site.single-news', $news->slug)); ?>"><?php echo e($news->title); ?></a></h3>
                                <p>
                                    <?php echo $news->content; ?>

                                </p>


                                <span class="post-date"><?php echo e($news->created_at->translatedFormat('M d, Y')); ?></span>
                                <span class="post-comment"><?php echo e(count($news->all_comments)); ?></span>
                                <span class="post-like"><?php echo e($news->likes); ?></span>
                            </div>

                        </div>

                        <div class="spacer-single"></div>

                        <div id="blog-comment">
                            <h3>Comments (<?php echo e(count($news->all_comments)); ?>)</h3>

                            <div class="spacer-half"></div>

                            <ol>
                                <?php $__currentLoopData = $news->all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="avatar">
                                        <img src="/public/images/avatar.jpg" alt=""/></div>
                                    <div class="comment-info">
                                        <span class="c_name"><?php echo e($c->user->name); ?></span>
                                        <span class="c_date id-color"><?php echo e($c->created_at->translatedFormat('d M Y')); ?></span>

                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="comment">
                                        <?php echo e($c->comment); ?>

                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>

                            <div class="spacer-single"></div>

                            <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                            <div id="comment-form-wrapper">
                                <h3>Leave a Comment</h3>
                                <div class="comment_form_holder">
                                    <form  class="form-border" method="post" action="<?php echo e(route('site.add_comment', $news->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <label>Message <span class="req">*</span></label>
                                        <textarea cols="10" rows="10" name="comment" id="message" class="form-control"></textarea>
                                        <div id="error_message" class="error">Please check your message</div>
                                        <div id="mail_success" class="success">Thank you. Your message has been sent.</div>
                                        <div id="mail_failed" class="error">Error, email not sent</div>
                                        <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <p id="btnsubmit">
                                            <input type="submit" id="send" value="Send" class="btn btn-custom" /></p>


                                    </form>
                                </div>
                            </div>
                                <?php endif; ?>
                        </div>

                    </div>

                    <div id="sidebar" class="col-md-3">
                        <div class="widget widget-post">
                            <h4>Recent Posts</h4>
                            <div class="small-border"></div>
                            <ul>
                                <?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span class="date text-capitalize" ><?php echo e($p->created_at->translatedFormat('d M')); ?></span><a href="<?php echo e(route('site.single-news', $p->slug)); ?>"><?php echo e($p->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>

                        <div class="widget widget-text">
                            <h4>About Us</h4>
                            <div class="small-border"></div>
                            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
                            sit aspernatur aut odit aut fugit, sed quia consequuntur magni
                        </div>
                        <div class="widget widget_tags">
                            <h4>Tags</h4>
                            <div class="small-border"></div>
                            <ul>
                                <li><a href="#link">Art</a></li>
                                <li><a href="#link">Application</a></li>
                                <li><a href="#link">Design</a></li>
                                <li><a href="#link">Entertainment</a></li>
                                <li><a href="#link">Internet</a></li>
                                <li><a href="#link">Marketing</a></li>
                                <li><a href="#link">Multipurpose</a></li>
                                <li><a href="#link">Music</a></li>
                                <li><a href="#link">Print</a></li>
                                <li><a href="#link">Programming</a></li>
                                <li><a href="#link">Responsive</a></li>
                                <li><a href="#link">Website</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/portfolio/resources/views/news-single.blade.php ENDPATH**/ ?>