jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2020, 3, 8, 8)}); // year, month, date, hour
        });
});		

